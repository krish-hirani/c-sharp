﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxunbox
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            object obj = i;//boxing (data type to object)
            Console.WriteLine(obj);
            int j = (int)obj;//unboxing(object type to data type)
            Console.WriteLine(j);
            Console.Read();
        }
    }
}
