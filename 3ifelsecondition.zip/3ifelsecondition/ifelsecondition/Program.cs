﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ifelsecondition
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter any number: ");
            int n = Convert.ToInt32(Console.ReadLine());
            /*int id=1,old_d=2,New_d=3;
            Console.WriteLine("Using Do...While Loop");
            do
            {
                 if(id<=3)
                 {
                     Console.Write(id+" ");
                     id++;
                 }
                 else
                 {
                     id=old_d*New_d;
                     if(id>=n)
                     {
                         break;
                     }
                     Console.Write(id+ " ");
                     old_d=New_d;
                     New_d=id;
                 }
            }while(id<=n);
            int fi = 1, old_f = 2, New_f = 3;
            Console.WriteLine();
            Console.WriteLine("Using For Loop");
            for (fi = 1; fi <= n; fi++)
            {
                if (fi <= 3)
                {
                    Console.Write(fi + " ");
                    //i++; as it is already incremented we don't need it to be incremented here
                }
                else
                {
                    fi = old_f * New_f;
                    if (fi >= n)
                    {
                        break;
                    }
                    Console.Write(fi + " ");
                    old_f = New_f;
                    New_f = fi;
                }
            }
            int wi=1,old_w=2,New_w=3;
            Console.WriteLine();
           Console.WriteLine("Using While Loop");
            while (wi <= n)
            {

                if (wi <= 3)
                {
                    Console.Write(wi + " ");
                    wi++;
                }
                else
                {
                    wi = old_w * New_w;
                    if (wi >= n)
                    {
                        break;
                    }
                    Console.Write(wi + " ");
                    old_w = New_w;
                    New_w  =wi;
                }
            }*/
           /* int i = 1, old = 2, New = 3;
            Console.WriteLine("Using Do...While Loop");
            do
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");
                    i++;
                }
                else
                {
                    i = old * New;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    old = New;
                    New = i;
                }
            } while (i <= n);
            int i = 1, old = 2, New = 3;
            Console.WriteLine();
            Console.WriteLine("Using For Loop");
            for (i = 1; i <= n; i++)
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");
                    //i++; as it is already incremented we don't need it to be incremented here
                }
                else
                {
                    i = old * New;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    old = New;
                    New = i;
                }
            }*/
            int i = 1, old = 2, New = 3;
            Console.WriteLine();
            Console.WriteLine("Using While Loop");
            while (i <= n)
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");
                    i++;
                }
                else
                {
                    i = old * New;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    old = New;
                    New = i;
                }
            }
            Console.Read();
        }
    }
}
